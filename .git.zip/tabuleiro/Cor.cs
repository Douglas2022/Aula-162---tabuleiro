﻿namespace tabuleiro
{
    enum Cor
    {
        Brnca,
        Preta,
        Amarela,
        Azul,
        Vermelho,
        Verde,
        Laranja
    }
}


